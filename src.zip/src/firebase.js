const firebaseConfig = {
    apiKey: "AIzaSyCtoDcj67UVXdShIldX4V9iK3KXrRZnY3Q",
    authDomain: "clone-a10d0.firebaseapp.com",
    projectId: "clone-a10d0",
    storageBucket: "clone-a10d0.appspot.com",
    messagingSenderId: "110797945876",
    appId: "1:110797945876:web:41fc1181a7e5e3a8b77b01"
  };